# Assignment 1
## Intro to System Calls

1. Reverse a big file
2. Reverse a big file with #segments specified & the segment itself
3. Print permissions of the files generated above.

### 3. Printing Permissions
Assumption: "Directory is created: Yes" only prints once, the rest 9 get printed for each in ["Assignemnt", "Assignment/1_file_name", "Assignment/2_file_name"]

### 2. Reverse with conditions
Nothing assumed

### 1. Reverse
Nothing assumed
